def A(param1, param2):
    print(f"Processing with {param1} and {param2}")
    print(f"Other lines of code before completion")
    return "Operation completed"