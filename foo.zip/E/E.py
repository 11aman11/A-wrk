def E(param1,param2):
    sum = int(param) + int(param2)
    print(f"{param1} + {param2} = {sum}")
    return "Success"

def A(param1, param2):
    print(f"Processing with {param1} and {param2}")
    print(f"Other lines of code before completion")
    return "Operation completed"