def B():
    print("Starting B function")
    #syntax error
    return "Done"